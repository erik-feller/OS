//Header of the main file
void req(char *input[]);
void res(char *output[]);
